# SP Connect

Projet Android de Service Plus Bénin / SP Connect.

## Flux actuel
Accueil → Élève → inscription → paiement Mobile Money (MTN, Moov, Celtis).
Les informations de l'élève sont transmises à l'écran de paiement et enregistrées avec la demande
dans Firestore (`payment_requests`), avec le statut `PENDING`.

## Mise en route (à faire une seule fois)
1. **Firebase Authentication** : console Firebase → Authentication → Sign-in method → activer **Anonyme**.
   Indispensable : les règles Firestore exigent un utilisateur authentifié.
2. **Règles Firestore** : publier `firestore/firestore.rules`
   (console Firebase → Firestore → Règles, ou `firebase deploy --only firestore:rules`).
3. **Clé API** : Google Cloud Console → Identifiants → restreindre la clé de `google-services.json`
   à l'application Android `com.spconnect.application` et à l'empreinte SHA-1 de votre clé de signature.
4. **Numéros Mobile Money** : remplacer « À CONFIGURER » dans `PaymentConfig.kt`.
   Tant qu'un numéro n'est pas configuré, le moyen de paiement est désactivé dans l'app.

## Validation des paiements par l'administration
Chaque demande est un document `payment_requests/{PROVIDER}_{référence}` : l'ID empêche de soumettre
deux fois la même référence. Pour valider : console Firebase → Firestore → ouvrir la demande →
vérifier la transaction dans votre compte Mobile Money → passer `status` à `CONFIRMED` ou `REJECTED`.

Les règles autorisent aussi la lecture et la mise à jour à un utilisateur ayant le custom claim
`admin = true`, pour un futur écran d'administration.

## Build
GitHub Actions (`.github/workflows/main.yml`) génère l'APK debug à chaque push sur `main`.
En local : `gradle assembleDebug` (Gradle 8.2, JDK 17).

## Paiement automatique
Le flux actuel est une **validation manuelle**. Pour débiter et confirmer automatiquement,
il faut une API Mobile Money marchande (identifiants + webhook côté serveur).
