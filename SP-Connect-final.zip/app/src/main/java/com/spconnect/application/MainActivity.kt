package com.spconnect.application

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 40, 32, 40)
        }

        layout.addView(TextView(this).apply {
            text = getString(R.string.app_name)
            textSize = 32f
            gravity = Gravity.CENTER
        })
        layout.addView(TextView(this).apply {
            text = getString(R.string.tagline)
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 32)
        })

        layout.addView(Button(this).apply {
            text = getString(R.string.role_eleve)
            setOnClickListener {
                startActivity(Intent(this@MainActivity, EleveActivity::class.java))
            }
        }, matchParentParams())

        listOf(
            R.string.role_parent, R.string.role_eleve_prof, R.string.role_prof,
            R.string.role_ecole, R.string.role_commercial, R.string.role_admin
        ).forEach { roleRes ->
            layout.addView(Button(this).apply {
                text = getString(roleRes)
                setOnClickListener {
                    Toast.makeText(this@MainActivity, R.string.coming_soon, Toast.LENGTH_SHORT).show()
                }
            }, matchParentParams())
        }

        setContentView(ScrollView(this).apply {
            isFillViewport = true
            addView(layout)
        })
    }

    private fun matchParentParams() =
        LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(0, 8, 0, 8) }
}
