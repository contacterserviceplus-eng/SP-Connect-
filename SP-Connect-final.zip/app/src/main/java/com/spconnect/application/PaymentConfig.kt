package com.spconnect.application

/**
 * Configuration des moyens de paiement SP Connect.
 * Remplacer les valeurs "À CONFIGURER" par les numéros professionnels validés
 * avant la mise en production. Tant qu'un numéro n'est pas configuré,
 * le moyen de paiement correspondant est désactivé dans l'application.
 */
object PaymentConfig {
    const val MTN_NUMBER = "À CONFIGURER"
    const val MOOV_NUMBER = "À CONFIGURER"
    const val CELTIS_NUMBER = "À CONFIGURER"

    const val CURRENCY = "FCFA"
    const val MAX_AMOUNT = 10_000_000L

    /** Code technique (utilisé dans Firestore), libellé affiché, numéro de destination. */
    data class Provider(val code: String, val label: String, val number: String) {
        val isConfigured: Boolean
            get() = number.isNotBlank() && !number.contains("CONFIGURER", ignoreCase = true)
    }

    val providers = listOf(
        Provider("MTN", "MTN Mobile Money", MTN_NUMBER),
        Provider("MOOV", "Moov Money", MOOV_NUMBER),
        Provider("CELTIS", "Celtis Money", CELTIS_NUMBER)
    )
}
