package com.spconnect.application

import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import java.util.UUID

class PaiementActivity : AppCompatActivity() {
    private val db by lazy { FirebaseFirestore.getInstance() }
    private val auth by lazy { FirebaseAuth.getInstance() }

    private lateinit var amountInput: EditText
    private lateinit var phoneInput: EditText
    private lateinit var referenceInput: EditText
    private lateinit var providerSpinner: Spinner
    private lateinit var statusText: TextView
    private lateinit var submitButton: Button

    private var student: Map<String, String> = emptyMap()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        student = mapOf(
            "nom" to (intent.getStringExtra(EleveActivity.EXTRA_NOM) ?: ""),
            "prenom" to (intent.getStringExtra(EleveActivity.EXTRA_PRENOM) ?: ""),
            "telephone" to (intent.getStringExtra(EleveActivity.EXTRA_TELEPHONE) ?: ""),
            "email" to (intent.getStringExtra(EleveActivity.EXTRA_EMAIL) ?: ""),
            "etablissement" to (intent.getStringExtra(EleveActivity.EXTRA_ETABLISSEMENT) ?: ""),
            "classe" to (intent.getStringExtra(EleveActivity.EXTRA_CLASSE) ?: ""),
            "matieres" to (intent.getStringExtra(EleveActivity.EXTRA_MATIERES) ?: ""),
            "adresse" to (intent.getStringExtra(EleveActivity.EXTRA_ADRESSE) ?: "")
        )
        if (student["nom"].isNullOrBlank() || student["prenom"].isNullOrBlank() ||
            student["telephone"].isNullOrBlank() || student["classe"].isNullOrBlank()
        ) {
            Toast.makeText(this, R.string.pay_missing_student, Toast.LENGTH_LONG).show()
            finish()
            return
        }

        setContentView(ScrollView(this).apply { addView(buildView()) })
    }

    private fun buildView(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 32)
        }

        root.addView(TextView(this).apply {
            text = getString(R.string.pay_title)
            textSize = 28f
            setPadding(0, 0, 0, 18)
        })
        root.addView(TextView(this).apply {
            text = getString(R.string.pay_intro)
            textSize = 16f
            setPadding(0, 0, 0, 18)
        })

        providerSpinner = Spinner(this)
        providerSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            PaymentConfig.providers.map { it.label }
        )
        root.addView(label(getString(R.string.pay_provider)))
        root.addView(providerSpinner, lp())

        amountInput = input(getString(R.string.pay_amount_hint), InputType.TYPE_CLASS_NUMBER, 8)
        root.addView(label(getString(R.string.pay_amount)))
        root.addView(amountInput, lp())

        phoneInput = input(getString(R.string.pay_phone_hint), InputType.TYPE_CLASS_PHONE, 20)
        root.addView(label(getString(R.string.pay_phone)))
        root.addView(phoneInput, lp())

        referenceInput = input(
            getString(R.string.pay_reference_hint),
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS,
            32
        )
        root.addView(label(getString(R.string.pay_reference)))
        root.addView(referenceInput, lp())

        val destination = TextView(this).apply {
            textSize = 15f
            setPadding(0, 12, 0, 12)
        }
        root.addView(destination)

        submitButton = Button(this).apply {
            text = getString(R.string.pay_submit)
            setOnClickListener { submitPayment() }
        }
        root.addView(submitButton, lp(20))

        providerSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                val provider = PaymentConfig.providers[position]
                if (provider.isConfigured) {
                    destination.text = getString(R.string.pay_destination, provider.number)
                    submitButton.isEnabled = true
                } else {
                    destination.text = getString(R.string.pay_not_configured)
                    submitButton.isEnabled = false
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }

        statusText = TextView(this).apply {
            textSize = 16f
            setPadding(0, 18, 0, 0)
        }
        root.addView(statusText)
        return root
    }

    private fun submitPayment() {
        val provider = PaymentConfig.providers[providerSpinner.selectedItemPosition]
        if (!provider.isConfigured) return

        val amount = amountInput.text.toString().trim().toLongOrNull()
        val phone = phoneInput.text.toString().filter { it.isDigit() }
        val reference = referenceInput.text.toString().trim()

        if (amount == null || amount <= 0 || amount > PaymentConfig.MAX_AMOUNT) {
            amountInput.error = getString(R.string.pay_amount_invalid)
            return
        }
        if (phone.length !in 8..15) {
            phoneInput.error = getString(R.string.pay_phone_invalid)
            return
        }
        if (reference.length !in 4..32 || !reference.all { it.isLetterOrDigit() && it.code < 128 }) {
            referenceInput.error = getString(R.string.pay_reference_invalid)
            return
        }

        submitButton.isEnabled = false
        statusText.text = getString(R.string.pay_sending)

        val user = auth.currentUser
        if (user != null) {
            save(user.uid, provider.code, amount, phone, reference)
        } else {
            auth.signInAnonymously()
                .addOnSuccessListener { result ->
                    val uid = result.user?.uid
                    if (uid != null) save(uid, provider.code, amount, phone, reference) else authFailed()
                }
                .addOnFailureListener { authFailed() }
        }
    }

    private fun authFailed() {
        statusText.text = getString(R.string.pay_error_auth)
        submitButton.isEnabled = true
    }

    private fun save(uid: String, providerCode: String, amount: Long, phone: String, reference: String) {
        val paymentId = UUID.randomUUID().toString()
        // ID déterministe : une même référence ne peut être soumise qu'une seule fois par moyen de paiement.
        val docId = "${providerCode}_$reference"

        val data = hashMapOf(
            "paymentId" to paymentId,
            "uid" to uid,
            "provider" to providerCode,
            "amount" to amount,
            "currency" to PaymentConfig.CURRENCY,
            "payerPhone" to phone,
            "transactionReference" to reference,
            "status" to "PENDING",
            "student" to student,
            "createdAt" to FieldValue.serverTimestamp()
        )

        db.collection("payment_requests").document(docId).set(data)
            .addOnSuccessListener {
                statusText.text = getString(R.string.pay_success, paymentId)
                Toast.makeText(this, R.string.pay_toast_ok, Toast.LENGTH_LONG).show()
            }
            .addOnFailureListener { error ->
                val denied = (error as? FirebaseFirestoreException)?.code ==
                    FirebaseFirestoreException.Code.PERMISSION_DENIED
                statusText.text = getString(
                    if (denied) R.string.pay_error_duplicate else R.string.pay_error_network
                )
                submitButton.isEnabled = true
            }
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 14f
        setPadding(0, 10, 0, 4)
    }

    private fun input(hint: String, type: Int, maxLen: Int): EditText = EditText(this).apply {
        this.hint = hint
        setSingleLine(true)
        inputType = type
        filters = arrayOf(InputFilter.LengthFilter(maxLen))
    }

    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { setMargins(0, top, 0, 8) }
}
