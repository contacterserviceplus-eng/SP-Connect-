package com.spconnect.application

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.util.Patterns
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class EleveActivity : Activity() {

    companion object {
        const val EXTRA_NOM = "nom"
        const val EXTRA_PRENOM = "prenom"
        const val EXTRA_TELEPHONE = "telephone"
        const val EXTRA_EMAIL = "email"
        const val EXTRA_ETABLISSEMENT = "etablissement"
        const val EXTRA_CLASSE = "classe"
        const val EXTRA_MATIERES = "matieres"
        const val EXTRA_ADRESSE = "adresse"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 40)
        }

        layout.addView(TextView(this).apply {
            text = getString(R.string.eleve_title)
            textSize = 28f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        })

        val textType = InputType.TYPE_CLASS_TEXT
        val nom = champ(R.string.eleve_nom, textType or InputType.TYPE_TEXT_FLAG_CAP_WORDS, 100)
        val prenom = champ(R.string.eleve_prenom, textType or InputType.TYPE_TEXT_FLAG_CAP_WORDS, 100)
        val telephone = champ(R.string.eleve_telephone, InputType.TYPE_CLASS_PHONE, 20)
        val email = champ(R.string.eleve_email, textType or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS, 120)
        val etablissement = champ(R.string.eleve_etablissement, textType or InputType.TYPE_TEXT_FLAG_CAP_WORDS, 120)
        val classe = champ(R.string.eleve_classe, textType or InputType.TYPE_TEXT_FLAG_CAP_WORDS, 60)
        val matieres = champ(R.string.eleve_matieres, textType or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES, 200)
        val adresse = champ(R.string.eleve_adresse, textType or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES, 200)

        listOf(nom, prenom, telephone, email, etablissement, classe, matieres, adresse)
            .forEach { layout.addView(it) }

        val continuer = Button(this).apply {
            text = getString(R.string.eleve_continue)
            setOnClickListener {
                val phoneDigits = telephone.text.toString().filter { it.isDigit() }
                val mail = email.text.toString().trim()
                when {
                    nom.text.isNullOrBlank() || prenom.text.isNullOrBlank() ||
                        telephone.text.isNullOrBlank() || classe.text.isNullOrBlank() ->
                        Toast.makeText(this@EleveActivity, R.string.eleve_required, Toast.LENGTH_SHORT).show()

                    phoneDigits.length !in 8..15 ->
                        telephone.error = getString(R.string.eleve_phone_invalid)

                    mail.isNotEmpty() && !Patterns.EMAIL_ADDRESS.matcher(mail).matches() ->
                        email.error = getString(R.string.eleve_email_invalid)

                    else -> startActivity(
                        Intent(this@EleveActivity, PaiementActivity::class.java)
                            .putExtra(EXTRA_NOM, nom.text.toString().trim())
                            .putExtra(EXTRA_PRENOM, prenom.text.toString().trim())
                            .putExtra(EXTRA_TELEPHONE, phoneDigits)
                            .putExtra(EXTRA_EMAIL, mail)
                            .putExtra(EXTRA_ETABLISSEMENT, etablissement.text.toString().trim())
                            .putExtra(EXTRA_CLASSE, classe.text.toString().trim())
                            .putExtra(EXTRA_MATIERES, matieres.text.toString().trim())
                            .putExtra(EXTRA_ADRESSE, adresse.text.toString().trim())
                    )
                }
            }
        }
        layout.addView(continuer, buttonParams())

        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun champ(labelRes: Int, type: Int, maxLen: Int) = EditText(this).apply {
        hint = getString(labelRes)
        setSingleLine(true)
        inputType = type
        filters = arrayOf(InputFilter.LengthFilter(maxLen))
        setPadding(0, 8, 0, 16)
    }

    private fun buttonParams() =
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(0, 24, 0, 0) }
}
