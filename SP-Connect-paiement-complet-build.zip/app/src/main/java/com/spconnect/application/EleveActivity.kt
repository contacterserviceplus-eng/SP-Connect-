package com.spconnect.application

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class EleveActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 40)
        }

        val title = TextView(this).apply {
            text = "Inscription Élève"
            textSize = 28f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }
        layout.addView(title)

        val nom = champ("Nom *")
        val prenom = champ("Prénom *")
        val telephone = champ("Téléphone *")
        val email = champ("Adresse e-mail")
        val etablissement = champ("Établissement")
        val classe = champ("Classe / Niveau *")
        val matieres = champ("Matières demandées")
        val adresse = champ("Adresse de résidence")

        listOf(nom, prenom, telephone, email, etablissement, classe, matieres, adresse)
            .forEach { layout.addView(it) }

        val continuer = Button(this).apply {
            text = "Continuer"
            setOnClickListener {
                if (nom.text.isNullOrBlank() || prenom.text.isNullOrBlank() ||
                    telephone.text.isNullOrBlank() || classe.text.isNullOrBlank()) {
                    Toast.makeText(
                        this@EleveActivity,
                        "Veuillez remplir les informations obligatoires.",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    startActivity(Intent(this@EleveActivity, PaiementActivity::class.java))
                }
            }
        }
        layout.addView(continuer, buttonParams())

        setContentView(layout)
    }

    private fun champ(label: String) = EditText(this).apply {
        hint = label
        setPadding(0, 8, 0, 16)
    }

    private fun buttonParams() =
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(0, 24, 0, 0) }
}
