package com.spconnect.application

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 40, 32, 40)
        }

        val title = TextView(this).apply {
            text = "SP Connect"
            textSize = 32f
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "La réussite de votre enfant, notre priorité."
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 32)
        }

        layout.addView(title)
        layout.addView(subtitle)

        val eleve = Button(this).apply {
            text = "Élève"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, EleveActivity::class.java))
            }
        }
        layout.addView(eleve, matchParentParams())

        listOf("Parent", "Élève-professeur", "Professeur titulaire",
            "École / Université", "Commercial", "Administration").forEach { role ->
            val button = Button(this).apply {
                text = role
            }
            layout.addView(button, matchParentParams())
        }

        setContentView(layout)
    }

    private fun matchParentParams() =
        LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(0, 8, 0, 8) }
}
