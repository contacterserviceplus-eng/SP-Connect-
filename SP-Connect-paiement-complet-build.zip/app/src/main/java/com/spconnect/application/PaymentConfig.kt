package com.spconnect.application

/**
 * Configuration des moyens de paiement SP Connect.
 * Remplacer les valeurs PLACEHOLDER par les numéros professionnels validés
 * avant la mise en production.
 */
object PaymentConfig {
    const val MTN_NUMBER = "À CONFIGURER"
    const val MOOV_NUMBER = "À CONFIGURER"
    const val CELTIS_NUMBER = "À CONFIGURER"

    const val CURRENCY = "FCFA"
}
