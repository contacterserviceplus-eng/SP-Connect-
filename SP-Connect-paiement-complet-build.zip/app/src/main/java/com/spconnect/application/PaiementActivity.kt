package com.spconnect.application

import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class PaiementActivity : AppCompatActivity() {
    private val db by lazy { FirebaseFirestore.getInstance() }
    private lateinit var amountInput: EditText
    private lateinit var phoneInput: EditText
    private lateinit var referenceInput: EditText
    private lateinit var providerSpinner: Spinner
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildView())
    }

    private fun buildView(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 32)
        }

        root.addView(TextView(this).apply {
            text = "Paiement SP Connect"
            textSize = 28f
            setPadding(0, 0, 0, 18)
        })
        root.addView(TextView(this).apply {
            text = "Choisissez votre moyen de paiement Mobile Money, effectuez le transfert, puis saisissez la référence de transaction."
            textSize = 16f
            setPadding(0, 0, 0, 18)
        })

        providerSpinner = Spinner(this)
        providerSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            listOf("MTN Mobile Money", "Moov Money", "Celtis Money")
        )
        root.addView(label("Moyen de paiement"))
        root.addView(providerSpinner, lp())

        amountInput = input("Montant en FCFA", "Ex. 5000", false)
        root.addView(label("Montant"))
        root.addView(amountInput, lp())

        phoneInput = input("Numéro utilisé pour le paiement", "Ex. 97xxxxxx", false)
        root.addView(label("Numéro payeur"))
        root.addView(phoneInput, lp())

        referenceInput = input("Référence / ID de transaction", "Ex. 123456789", false)
        root.addView(label("Référence de transaction"))
        root.addView(referenceInput, lp())

        val destination = TextView(this).apply {
            textSize = 15f
            setPadding(0, 12, 0, 12)
        }
        root.addView(destination)
        providerSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                destination.text = destinationText(position)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        destination.text = destinationText(0)

        val submit = Button(this).apply {
            text = "Envoyer la demande de validation"
            setOnClickListener { submitPayment() }
        }
        root.addView(submit, lp(20))

        statusText = TextView(this).apply {
            textSize = 16f
            setPadding(0, 18, 0, 0)
        }
        root.addView(statusText)
        return root
    }

    private fun destinationText(position: Int): String {
        val number = when (position) {
            0 -> PaymentConfig.MTN_NUMBER
            1 -> PaymentConfig.MOOV_NUMBER
            else -> PaymentConfig.CELTIS_NUMBER
        }
        return "Numéro SP Connect : $number\nEffectuez d'abord le transfert, puis envoyez la référence ci-dessus."
    }

    private fun submitPayment() {
        val amount = amountInput.text.toString().trim()
        val phone = phoneInput.text.toString().trim()
        val reference = referenceInput.text.toString().trim()
        val provider = providerSpinner.selectedItem.toString()

        if (amount.toLongOrNull()?.let { it > 0 } != true) {
            amountInput.error = "Montant invalide"
            return
        }
        if (phone.length < 8) {
            phoneInput.error = "Numéro invalide"
            return
        }
        if (reference.length < 4) {
            referenceInput.error = "Référence invalide"
            return
        }

        statusText.text = "Envoi de la demande..."
        val paymentId = UUID.randomUUID().toString()
        val data = hashMapOf(
            "paymentId" to paymentId,
            "provider" to provider,
            "amount" to amount.toLong(),
            "currency" to PaymentConfig.CURRENCY,
            "payerPhone" to phone,
            "transactionReference" to reference,
            "status" to "PENDING",
            "createdAt" to SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(Date())
        )

        db.collection("payment_requests").document(paymentId).set(data)
            .addOnSuccessListener {
                statusText.text = "Demande enregistrée. Référence SP Connect : $paymentId\nStatut : EN ATTENTE DE VALIDATION"
                Toast.makeText(this, "Paiement envoyé pour validation", Toast.LENGTH_LONG).show()
            }
            .addOnFailureListener { error ->
                statusText.text = "Impossible d'enregistrer le paiement : ${error.localizedMessage ?: "erreur réseau"}"
            }
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 14f
        setPadding(0, 10, 0, 4)
    }

    private fun input(hint: String, placeholder: String, password: Boolean): EditText = EditText(this).apply {
        this.hint = hint
        setText("")
        setSingleLine(true)
        if (password) inputType = 2
    }

    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { setMargins(0, top, 0, 8) }
}
