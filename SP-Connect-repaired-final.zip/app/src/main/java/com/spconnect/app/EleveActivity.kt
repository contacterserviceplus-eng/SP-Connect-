package com.spconnect.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class EleveActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        val title = TextView(this).apply {
            text = "Inscription élève"
            textSize = 24f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }

        val nom = EditText(this).apply {
            hint = "Nom et prénom"
        }

        val telephone = EditText(this).apply {
            hint = "Téléphone"
            inputType = android.text.InputType.TYPE_CLASS_PHONE
        }

        val classe = EditText(this).apply {
            hint = "Classe"
        }

        val continuer = Button(this).apply {
            text = "Continuer vers le paiement"
            setOnClickListener {
                if (nom.text.toString().trim().isEmpty() ||
                    telephone.text.toString().trim().isEmpty() ||
                    classe.text.toString().trim().isEmpty()) {
                    Toast.makeText(this@EleveActivity, "Veuillez remplir tous les champs.", Toast.LENGTH_SHORT).show()
                } else {
                    startActivity(Intent(this@EleveActivity, PaiementActivity::class.java))
                }
            }
        }

        layout.addView(title)
        layout.addView(nom)
        layout.addView(telephone)
        layout.addView(classe)
        layout.addView(continuer)
        setContentView(layout)
    }
}
