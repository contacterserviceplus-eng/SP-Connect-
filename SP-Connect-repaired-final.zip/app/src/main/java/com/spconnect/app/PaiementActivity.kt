package com.spconnect.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class PaiementActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        val title = TextView(this).apply {
            text = "Paiement SP Connect"
            textSize = 24f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }

        val montant = EditText(this).apply {
            hint = "Montant (FCFA)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }

        val numero = EditText(this).apply {
            hint = "Numéro Mobile Money"
            inputType = android.text.InputType.TYPE_CLASS_PHONE
        }

        val payer = Button(this).apply {
            text = "Continuer"
            setOnClickListener {
                if (montant.text.toString().trim().isEmpty() ||
                    numero.text.toString().trim().isEmpty()) {
                    Toast.makeText(this@PaiementActivity, "Veuillez remplir les informations.", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@PaiementActivity, "Demande de paiement enregistrée.", Toast.LENGTH_LONG).show()
                }
            }
        }

        layout.addView(title)
        layout.addView(montant)
        layout.addView(numero)
        layout.addView(payer)
        setContentView(layout)
    }
}
