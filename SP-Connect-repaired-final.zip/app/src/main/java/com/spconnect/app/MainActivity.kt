package com.spconnect.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }

        val title = TextView(this).apply {
            text = "SP Connect"
            textSize = 28f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
        }

        val subtitle = TextView(this).apply {
            text = "Service Plus Bénin – Éducation"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 32)
        }

        val inscription = Button(this).apply {
            text = "Inscription élève"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, EleveActivity::class.java))
            }
        }

        val paiement = Button(this).apply {
            text = "Paiement"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, PaiementActivity::class.java))
            }
        }

        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(inscription)
        layout.addView(paiement)
        setContentView(layout)
    }
}
